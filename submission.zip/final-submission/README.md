# CS 5220 Final
Hogwild and Buckwild Final Project!

Authors: Alex Renda, Matthew Gharrity, Matt Li

To run:
$ ssh totient
$ qsub -I
$ cd path/to/repo/
$ cd src
$ module load intel
$ make
$ ./main 1> log.txt
